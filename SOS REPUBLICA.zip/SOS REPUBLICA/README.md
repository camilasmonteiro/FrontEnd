Esse demo foi desenvolvido a partir de um curso disponibilizado pela empresa SchoolOfNet. O principal objetivo do projeto foi utilizar a linguagem de marcação (tags) HTML, com o conjunto CSS e JQuery.

O website criado utiliza imagens editadas e não poderá ser utilizada para comercialização sem autorização.

Os exemplos tais como a ideia, nomes e textos são fictícios, para uso de visualização DEMO.

MontechIT - Soluções tecnólogicas.